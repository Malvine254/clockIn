<?php 
	require_once 'config.php';
	if (isset($_GET['c'])) {
		$id = $_GET['c'];
		$sql = $conn->query("UPDATE users SET status2=1 WHERE id='$id'");
		if ($sql) {
			echo "<script>window.location.assign('#users')</script>";
			// code...
		}
	}
	if (isset($_GET['i'])) {
		$numbering = 1;
	if (isset($_POST['search_btn'])) {
		$search = mysqli_real_escape_string($conn,$_POST['search']);
	 	$select = $conn->query("SELECT * FROM users WHERE name LIKE '%$search%' OR unique_code LIKE '%$search%'");
	 	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			echo "
			<tr >
				<td>".$numbering++."</td>
				<td>".$row['name']."</td>
				<td>".$row['email']."</td>
				<td>".date("d/m/y h:i:sa",$row['time_in'])."</td>
				<td>".date("d/m/y h:i:sa",$row['time_out'])."</td>
				<td>".$row['department']."</td>
				<td>".$row['positions']."</td>
				<td><a href='../".$row['image']."'><img width='30px' height='30px' src='../".$row['image']."' style='border-radius:50%;'/></td>
				<td><a style='padding:10px; font-size:25px;' class='zmdi zmdi-delete text-danger' href='?i=".$row['id']."'></a></td>
			<tr>";
		
		}
	}else{
		echo "<tr colspan='7'>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td class='text-danger'>No search results</td>
				<td></td>
				<td></td>
				<td></td>
				
			<tr>";
	}
	 }else{
	 	$check = $conn->query("SELECT * FROM users WHERE status2=0");
	if ($check->num_rows>0) {
		while ($row=$check->fetch_assoc()) {
			echo "
			<tr style='background:".changeBackColor($row['status2'])."; color:".textColor($row['status2']).";'>
				<td>".$numbering++."</td>
				<td>".$row['name']."</td>
				<td>".$row['email']."</td>
				<td>".checkStatus2($row['time_in'])."</td>
				<td>".checkStatus2($row['time_out'])."</td>
				<td>".$row['department']."</td>
				<td>".$row['positions']."</td>
				<td><a href='../".$row['image']."'><img width='30px' height='30px' src='../".$row['image']."' style='border-radius:50%;'/></td>
				<td><a href='?c=".$row['id']."' class='btn btn-light'>MarkRead</button></td>
				<td><a style='padding:10px; font-size:25px;' class='zmdi zmdi-delete text-danger' href='?i=".$row['id']."'></a></td>
			<tr>";
		
		}
	}else{
		echo "<tr>
				
				<td colspan='10' class='text-danger text-center'>No new Messages found</td>
				
				
			<tr>";
	}

	 } 
	}else{
		$numbering = 1;
	if (isset($_POST['search_btn'])) {
		$search = mysqli_real_escape_string($conn,$_POST['search']);
	 	$select = $conn->query("SELECT * FROM users WHERE name LIKE '%$search%'");
	 	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			echo "
			<tr>
				<td>".$numbering++."</td>
				<td>".$row['name']."</td>
				<td>".$row['email']."</td>
				<td>".date("d/m/y h:i:sa",$row['time_in'])."</td>
				<td>".date("d/m/y h:i:sa",$row['time_out'])."</td>
				<td>".$row['department']."</td>
				<td>".$row['positions']."</td>
				<td><a href='../".$row['image']."'><img width='30px' height='30px' src='../".$row['image']."' style='border-radius:50%;'/></td>
				<td><a style='padding:10px; font-size:25px;' class='zmdi zmdi-delete text-danger' href='?i=".$row['id']."'></a></td>
			<tr>";
		
		}
	}else{
		echo "<tr colspan='7'>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td class='text-danger'>No search results</td>
				<td></td>
				<td></td>
				<td></td>
				
			<tr>";
	}
	 }else{
	 	$check = $conn->query("SELECT * FROM users ORDER BY id ASC");
	if ($check->num_rows>0) {
		while ($row=$check->fetch_assoc()) {
			echo "
			<tr style='background:".changeBackColor($row['status2']).";'>
				<td>".$numbering++."</td>
				<td>".$row['name']."</td>
				<td>".$row['email']."</td>
				<td>".checkStatus2($row['time_in'])."</td>
				<td>".checkStatus2($row['time_out'])."</td>
				<td>".$row['department']."</td>
				<td>".$row['positions']."</td>
				<td><a href='../".$row['image']."'><img width='30px' height='30px' src='../".$row['image']."' style='border-radius:50%;'/></td>
				<td><a href='?c=".$row['id']."' class='btn btn-light'>".statusChecker($row['status2'])."</a></td>
				<td><a style='padding:10px; font-size:25px;' class='zmdi zmdi-delete text-danger' href='?i=".$row['id']."'></a></td>
			<tr>";
		
		}
	}

	 } 
	}
	

	 function checkStatus2($sign_in){
	if ($sign_in==0) {
		return "Not signed";
	}else{
		return date("d/m/y h:i:sa",$sign_in);
		 
	}
}

	 function changeBackColor($status){
	if ($status==0) {
		return "red";
	}else{
		return "white";
		 
	}
}
	function textColor($status){
	if ($status==0) {
		return "white";
	}else{
		return "black";
		 
	}
}
	function statusChecker($status){
	if ($status==0) {
		return "markRead";
	}else{
		return "Read";
		 
	}

}




	
	


 ?>