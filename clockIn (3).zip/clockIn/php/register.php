<?php 
if (isset($_POST['signup'])) {
	session_start();
	require_once 'config.php';
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$id_no = mysqli_real_escape_string($conn, $_POST['id_no']);
	$image = mysqli_real_escape_string($conn, $_FILES['image']['name']);
	$department = mysqli_real_escape_string($conn, $_POST['department']);
	$positions = mysqli_real_escape_string($conn, $_POST['positions']);
	$target = "images/".basename($image);
	$unique_code = substr(rand(1000,99999999999), 0,6);
	$imageFileType=strtolower(pathinfo($target,PATHINFO_EXTENSION));
	$extensions_arr=array("jpg","png","jpeg");
	$check = $conn->query("SELECT * FROM users WHERE email='$email' AND id_no='$id_no' ");
	if ($check->num_rows>0) {
		echo "<script>alert('Email or ID Number is taken')</script>";
	}else{
		$_SESSION['verify_session'] = "<b>" .$name. "</b> your unique code is <b>". $unique_code ." </b>remember not to share with anyone as this code will be used for signing in."; 
	if (in_array($imageFileType,$extensions_arr)){
		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
			$result = $conn->query("INSERT INTO users (name,email,id_no,image,unique_code,department,positions) VALUES('$name','$email','$id_no','$target','$unique_code','$department','$positions')");
			if ($result) {
				echo "<script>alert('Registration was successful!!');window.location.assign('verify.php');</script>";
			}else{
				echo "<script>alert('Registration failed!!')</script>";
			}
		}else{
			echo "<script>alert('Image was not Moved!!')</script>";
		}
	}else{
			echo "<script>alert('Please choose an image!!')</script>";
		}

	}

	

}





 ?>