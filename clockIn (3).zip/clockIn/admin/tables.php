<?php require '../php/admin_session_checker.php'; ?>
<?php require '../php/delete.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
     <link rel="stylesheet" href="../fonts/material-icon/css/material-design-iconic-font.min.css"> 
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <script scr="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script scr="../js/popper.min.js"></script>

</head>
<body>
    <style type="text/css">
        nav{
            background: maroon;
            padding: 20px;
            border-radius: 10px;
        }
        nav a{
            color: white;
            padding: 20px;
        }
    </style>
    <center>
        <nav>
         <a href="logout.php"><img style="padding:5px;border-radius: 50%;" width="40px" height="40px" src="../images/logout.jpg">Logout</a>
         <a href="dashboard.php">Dashboard</a>
         <a href="user.php">User</a>
         <a href="tables.php">Tables</a>
          <a href="tables.php?i#users ">Notification <span class="badge"><sup class="text-danger  bg-light" style="border-radius: 50%; padding:4px;"><?php include '../php/notifications.php'; ?></sup></span></a>
         </nav>
    </center>


<section class="signup" style="margin-top:50px;">
<div class="container shadow-lg p-3 mb-5 bg-white rounded col-md-10">
    <div class="signup-content table-responsive">
              <div class="row">
                <div class="col-6">
                     <h2 id="attendance" class="form-title text-center">All Attendances</h2>
                </div>
                  <div class="col-6">
                      <form method="POST" class="form-inline">
                        <input style="border-right-color: white;" class="form-control mr-sm-0 col" type="search" aria-label="Search" name="search" placeholder="Search by name...">
                        <button name="search_btn_two" class="btn btn-info my-2 my-sm-0 zmdi zmdi-search"></button>
                      </form>
                   </div>
              </div>
            <table class="table table-bordered">
                <tr class="text-primary">
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>SignIn at</th>
                    <th>SignOut at</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                <?php include '../php/display_attendance_table.php'; ?>
                  
            </table>
    </div>
</div>
</section>

<section class="signup" style="margin-bottom:150px;">
<div class="container shadow-lg p-3 mb-5 bg-white rounded col-md-10">
    <div class="signup-content table-responsive">
            <div class="row">
                <div class="col-6">
                    <h2 id="users" class="form-title text-center">Users Table</h2>
                </div>
            <div class="col-6">
                      <form method="POST" class="form-inline">
                        <input style="border-right-color: white;" class="form-control mr-sm-0 col" type="search" aria-label="Search" name="search" placeholder="Search by name...">
                        <button name="search_btn" class="btn btn-info my-2 my-sm-0 zmdi zmdi-search"></button>
                      </form>
                   </div>
               </div>
          
            <table class="table table-bordered">
                <tr class="text-primary">
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>SignIn at</th>
                    <th>SignOut at</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Image</th>
                    <th>Mark as Read</th>
                    <th>Action</th>
                </tr>
                <?php include '../php/display_users_table.php'; ?>
                  
            </table>
    </div>
</div>
</section>




<script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../js/main.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        setInterval(function(){
            $("#time").load("../php/time.php");
        },100)
        
    })
</script>
</body>
</html>