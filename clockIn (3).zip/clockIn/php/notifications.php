<?php 
include "config.php";
$selectall = $conn->query("SELECT * FROM users WHERE status2 = 0");
echo $selectall->num_rows;
// while ($row=$selectall->fetch_assoc) {
// 	// code...
// }


 ?>