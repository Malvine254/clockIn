<?php 
date_default_timezone_set("Africa/Nairobi");
require 'config.php';
$sign_in_time = "07:00pm";
$sign_out_time = "04:00:00pm";
//$index = 1; 
$check = $conn->query("SELECT * FROM users");
	$time_now = strtotime(date("h:i:sa"));
if ($time_now>=strtotime($sign_in_time) && $time_now<=strtotime($sign_out_time)) {
	//echo "true";
	$conn->query("UPDATE users SET time_in=0,time_out=0");
}else{
	$select = $conn->query("SELECT * FROM users ORDER BY id ASC");
	while ($row=$select->fetch_assoc()) {
		$id_one = $row['id'];
	}
	$select = $conn->query("SELECT * FROM attendances ORDER BY id ASC");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
		$id_two = $row['id_auto'];
		if ($id_one==$id_two) {
			//echo "same";
		}else{
			$final = $conn->query("INSERT INTO attendances(id_auto,name,time_in,time_out,unique_code,image,email,id_no,department,positions) SELECT id,name,time_in,time_out,unique_code,image,email,id_no,department,positions FROM users ");
				if ($final) {
					//echo "success";
				}else{
					echo "failed";
				}
		}
	}
	}else{
		$final = $conn->query("INSERT INTO attendances(id_auto,name,time_in,time_out,unique_code,image,email,id_no,department,positions) SELECT id,name,time_in,time_out,unique_code,image,email,id_no,department,positions FROM users ");
				if ($final) {
					//echo "success";
				}else{
					echo "failed";
				}
	}
	
	
	
}


 ?>