<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form by Colorlib</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
</head>
<body style="margin-top: 100px; background: black;">

    <div>

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title text-center">Login Unique Code </h2>
                        <p><?php session_start(); if ($_SESSION['verify_session']=="") {
                           header('location:login.php');
                        } else{
                            echo $_SESSION['verify_session'];
                        } ?>
                            
                        </p>

                    </div>
                    <div class="signup-image">
                        <figure><img style="border-radius: 10px;" src="images/encrypt.jpg" alt="sing up image"></figure>
                        <a href="login.php" class="btn btn-info">Take Me to Login</a>
                    </div>
                </div>
            </div>
        </section>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>