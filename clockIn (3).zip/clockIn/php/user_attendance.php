<?php 
	require_once 'config.php';
	$numbering = 1;
	$unique_code = $_SESSION['unique_code'];
	$select = $conn->query("SELECT * FROM attendances WHERE unique_code=$unique_code");
	if ($select->num_rows>0) {

		while($row=$select->fetch_assoc()){
			$date = $row['time_in'];
			echo 
			"
				<tr>
					<td>".$numbering++."</td>
					<td>".date("h:i:sa",$row['time_in'])."</td>
					<td>".date("h:i:sa",$row['time_out'])."</td>
					<td>".date("d/m/y",$date)."</td>
				</tr>
			";
		}
	}else{
		echo "
		<tr>
			<td class='text-center text-danger' colspan='4'>No data found!<td>
		</tr>";

	}

 ?>