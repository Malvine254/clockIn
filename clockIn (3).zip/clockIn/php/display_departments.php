<?php 
	require_once 'config.php';
	 	$select = $conn->query("SELECT * FROM department");
	 	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$positons = explode(",",$row['positions']);
			for ($i=0; $i <count($positons) ; $i++) { 
				echo "<option>".$positons[$i]."</option>";
			}
			
		
		}
	}
	
	
	


 ?>