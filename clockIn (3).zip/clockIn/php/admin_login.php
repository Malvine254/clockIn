<?php 
	if (isset($_POST["login_btn"])) {
	session_start();
	include "config.php";
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);
	$checkEmail = $conn->query("SELECT  * FROM admin WHERE email='$email' AND password='$password'");
	
	if ($checkEmail->num_rows>0) {
		
		$_SESSION['email']=$email;
		header("location:dashboard.php");
		
	}else{
		echo "Incorrect Credentials!!";
		}
	}
	

 ?>