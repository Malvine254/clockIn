<?php require 'php/check_session.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
     <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css"> 
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <script scr="bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script scr="js/popper.min.js"></script>

</head>
<style type="text/css">
    .topMenu {
  padding: 17px;
}
.topMenu a {  
  padding: 17px;
}
.topMenu a:hover {  
  padding: 17px;
  color: white;
  background: black;
}

</style>
<body style="background: teal;">
    <div class=" container rounded bg-white mt-5 mb-5 col-md-11">
           <!-- <a href="php/unset.php"><img style="padding:5px;" width="40px" height="40px" src="images/logout.jpg">Logout</a> -->
        <div class="topMenu shadow">
              <a href="index.php"><i class="zmdi zmdi-home"></i> Home</a>
              <a href="profile.php"><i class="zmdi zmdi-account"></i> Profile</a>
              <a href="attendance.php"><i class="zmdi zmdi-menu"></i> Attendance</a>
              <a href="php/unset.php"><i class="zmdi zmdi-power"></i> Logout</a>
        </div>
        <br>
        <hr>
         <h4 class="text-center">Attendance History</h4>
         <hr>
        <div class="row">
            <div class=" col-md-12 p-3 py-5">
               <div class="d-flex justify-content-between align-items-center mb-3">
                </div>
               <center>
                    <div class="container">
                        <?php include 'php/sort_attendance.php'; ?>
                    <form method="POST" class="form-group col-md-8">
                        <div class="row">
                            <select name="attendance_selected" class="form-control col-md-8">
                                <option disabled selected>Order by....</option>
                                <option>Ascending Order</option>
                                <option>Descending Order</option>
                            </select>
                            <button name="confirm_attendance" class="btn btn-primary col-md-2">Confirm</button>
                        </div>
                    </form>
                </div>
               </center>
                <table class="table table-bordered ">
                    <tr class="text-primary">
                        <th>#</th>
                        <th>SignIn at</th>
                        <th>SignOut at</th>
                        <th>Date</th>
                    </tr>
                   <?php include 'php/user_attendance.php'; ?>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        setInterval(function(){
            $("#time").load("php/time.php");
        },100)
        
    })
</script>
</body>
</html>