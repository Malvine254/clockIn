<?php 
if (isset($_POST['confirm_attendance'])) {
	$attendance_selected = $_POST['attendance_selected'];
if ($attendance_selected==="Ascending Order") {
	require_once 'config.php';
	$numbering = 1;
	$unique_code = $_SESSION['unique_code'];
	$select = $conn->query("SELECT * FROM attendances WHERE unique_code=$unique_code ORDER BY id ASC");
	if ($select->num_rows>0) {
		while($row=$select->fetch_assoc()){
			echo 
			"
				<tr>
					<td>".$numbering."</td>
					<td>".$row['time_in']."</td>
					<td>".$row['time_out']."</td>
					<td>date</td>
				</tr>
			";
		}
	}else{
		echo "
		<tr>
			<td class='text-center text-danger' colspan='4'>No data found!<td>
		</tr>";

	}
}else if($attendance_selected==="Descending Order"){
	require_once 'config.php';
	$numbering = 1;
	$unique_code = $_SESSION['unique_code'];
	$select = $conn->query("SELECT * FROM attendances WHERE unique_code=$unique_code ORDER BY id DESC ");
	if ($select->num_rows>0) {
		while($row=$select->fetch_assoc()){
			echo 
			"
				<tr>
					<td>".$numbering."</td>
					<td>".$row['time_in']."</td>
					<td>".$row['time_out']."</td>
					<td>date</td>
				</tr>
			";
		}
	}else{
		echo "
		<tr>
			<td class='text-center text-danger' colspan='4'>No data found 5!<td>
		</tr>";

	}

}
}
	

 ?>