<?php 
if (isset($_GET['i'])) {
	include 'config.php';
	$id = $_GET['i'];
	$delete = $conn->query("DELETE FROM users WHERE id='$id'");

}else if (isset($_GET['a'])) {
	include 'config.php';
	$id = $_GET['a'];
	$delete = $conn->query("DELETE FROM attendances WHERE id='$id'");

}


 ?>