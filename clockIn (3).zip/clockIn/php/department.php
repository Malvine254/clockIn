<?php 
if (isset($_POST['continue_btn'])) {
	$numbering = 1;
	$number = mysqli_real_escape_string($conn,$_POST['number']);
	for ($i=0; $i <$number ; $i++) { 
		$input = "<div class='col-md-3'><label class='labels'> Depart Position ".$numbering++."</label><input type='text' placeholder='Department Name' class='form-control' name='positions[]' required></div>";
		echo $input;
		
	}
} 
if (isset($_POST['add_depart_btn'])) {
	$positions = $_POST['positions'];
	$department_name = mysqli_real_escape_string($conn,$_POST['depart_name']);
	$final_positions = implode(",",$positions);
	$insert = $conn->query("INSERT INTO department (department_name,positions) VALUES('$department_name','$final_positions')");
	if ($insert) {
		echo "<script>alert('Department Added Successfully".$final_positions."')</script>";
	}else{
		echo "<script>alert('Failed to Add Department!!')</script>";
	}
} 
?>