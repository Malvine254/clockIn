<?php require '../php/admin_session_checker.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
     <link rel="stylesheet" href="../fonts/material-icon/css/material-design-iconic-font.min.css"> 
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <script scr="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script scr="../js/popper.min.js"></script>

</head>
<body>
    <style type="text/css">
        nav{
            background: maroon;
            padding: 20px;
            border-radius: 10px;
        }
        nav a{
            color: white;
            padding: 20px;
        }
    </style>
    <center>
        <nav>
         <a href="logout.php"><img style="padding:5px;border-radius: 50%;" width="40px" height="40px" src="../images/logout.jpg">Logout</a>
         <a href="dashboard.php">Dashboard</a>
         <a href="user.php">User</a>
         <a href="tables.php">Tables</a>
         <a href="tables.php?i#users ">Notification <span class="badge"><sup class="text-danger  bg-light" style="border-radius: 50%; padding:4px;"><?php include '../php/notifications.php'; ?></sup></span></a>
         </nav>
    </center>
   

<center>
    <section class="signup" style="margin-top:100px;">
<div class="container shadow-lg p-3 mb-5 bg-white rounded col-md-10">
    <h2 class="form-title text-center">Dashboard</h2>
    <div  style="margin-top: 100px;" class="row">
        <div class="signup-content table-responsive col" >
          <div style="width: 250px;height: 150px; border-radius:10px;" class="bg-info">
              <h4 style="padding:10px;" class="text-light text-center">Users</h4>
              <h1 style="padding:15px;" class="text-light text-center">
                <?php 
                require_once '../php/config.php';
                $check = $conn->query("SELECT * FROM users");
                echo $check->num_rows;
                ?>
              </h1>
          </div>
    </div>
    <div class="signup-content table-responsive col" style="margin-bottom: 100px;">
          <div style="width: 250px;height: 150px; border-radius:10px;" class="bg-warning">
              <h4 style="padding:10px;" class="text-light text-center">Attendances</h4>
              <h1 style="padding:15px;" class="text-light text-center">
                  <?php 
                require_once '../php/config.php';
                $check = $conn->query("SELECT * FROM attendances");
                echo $check->num_rows;
                ?>
              </h1>
          </div>
    </div>
    </div>
    
</div>
</section>
</center>
<script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../js/main.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        setInterval(function(){
            $("#time").load("../php/time.php");
        },100)
        
    })
</script>
</body>
</html>