<?php require '../php/admin_session_checker.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
     <link rel="stylesheet" href="../fonts/material-icon/css/material-design-iconic-font.min.css"> 
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <script scr="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script scr="../js/popper.min.js"></script>

</head>
<body>
    <style type="text/css">
        nav{
            background: maroon;
            padding: 20px;
            border-radius: 10px;
        }
        nav a{
            color: white;
            padding: 20px;
        }
    </style>
    <center>
        <nav>
         <a href="logout.php"><img style="padding:5px;border-radius: 50%;" width="40px" height="40px" src="../images/logout.jpg">Logout</a>
         <a href="dashboard.php">Dashboard</a>
         <a href="user.php">User</a>
         <a href="tables.php">Tables</a>
          <a href="tables.php?i#users ">Notification <span class="badge"><sup class="text-danger  bg-light" style="border-radius: 50%; padding:4px;"><?php include '../php/notifications.php'; ?></sup></span></a>
         </nav>
    </center>
    <div style="margin-bottom:150px;" class="container rounded shadow-lg p-3 mb-5 bg-white  bg-white mt-5 mb-5 col-md-10">
    <div class="row">
        <div class="col-md-3 border-right">
             <?php 
                require_once '../php/config.php';
                $check = $conn->query("SELECT * FROM admin WHERE email='".$_SESSION['email']."' ");
                if ($check->num_rows>0) {
                    while ($row=$check->fetch_assoc()) {
                       echo "<div class='d-flex flex-column align-items-center text-center p-3 py-5'><img class='rounded-circle mt-5' width='150px' height='150px' src='".$row['image']."'><span class='font-weight-bold'>".$row['name']."</span><span class='text-black-50'>".$row['email']."</span><span> </span></div>";
                    }
                }
                ?>
            
        </div>
        <div class="col-md-5 border-right">
             <?php include '../php/add_admin.php'; include '../php/edit_admin_profile.php' ?>
            <form method='post' enctype="multipart/form-data">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Edit Profile</h4> 
                </div>
                <div class="row mt-3">
                    <?php 
                        require_once '../php/config.php';
                        $check = $conn->query("SELECT * FROM admin WHERE email='".$_SESSION['email']."' ");
                        if ($check->num_rows>0) {
                            while ($row=$check->fetch_assoc()) {
                               echo " 
                               <div class='col-md-12'><label class='labels'>Full Name</label><input name='name' type='text' class='form-control' value='".$row['name']."' required></div>
                                <div class='col-md-12'><label class='labels'>Profile Picture</label><input  type='file' name='image'  class='form-control' required></div>
                               <div class='col-md-12'><label class='labels'>Email Address</label><input disabled type='email' value='".$row['email']."' class='form-control' 
                                <div class='col-md-12'><label class='labels'>Position</label><input disabled type='text'  class='form-control' value='Admin' required></div>
                                ";
                            }
                        }


                     ?>
                  
                </div>
                <div class="mt-5 text-center"><button name="update_profile" class="btn btn-primary profile-button" type="submit">Edit Profile</button></div>
            </form>
            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 py-5">
               <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Add Admin</h4>
                </div>
               <form method="POST" class="form-group">
                   <div class='col-md-12'><label class='labels'>Full Name</label><input name='name' type='text' placeholder="Full Name" class='form-control'  required></div>
                   <div class='col-md-12'><label class='labels'>Email Address</label><input type='email' placeholder="Email Address" class='form-control' name="email" required></div>
                    <div class='col-md-12'><label class='labels'>One time Password</label><input name="password" type='text' class='form-control' value="admin"  required></div>
                    <div class='col-md-12'><label class='labels'>Position</label><input disabled type='text' class='form-control' value='Admin' required></div>
                    <div class="mt-5 text-center"><button name="add_admin_btn" class="btn btn-primary profile-button" type="submit">Add Admin </button></div>               </form>
               </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

    <div style="margin-bottom:150px;" class="container rounded shadow-lg p-3 mb-5 bg-white  bg-white mt-5 mb-5 col-md-10">
    <div class="row">
        <div class="col-md-12">
            <div class="p-3 py-5">
               <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Add Department</h4>
                </div>
               <form method="POST" class="form-group col-md-10">
                   <div class="row">
                        <div class='col-md-6'><label class='labels'>Department Name</label><input id="depart_name" name='depart_name' type='text' placeholder="Department Name" class='form-control'  required value="<?php if(isset($_POST['continue_btn'])){echo $_POST['depart_name'];} ?>"></div>
                       <div class='col-md-6'><label class='labels'>No of Depart Positions</label><input type='number' placeholder="No of Depart Positions" class='form-control' id="number" name="number" required value="<?php if(isset($_POST['continue_btn'])){echo $_POST['number'];} ?>"></div>
                       </div>
                       <div class="row">
                            <?php include '../php/department.php'; ?>
                       </div>
                       <?php if (isset($_POST['continue_btn'])): ?>
                        <div id="department" class="mt-5 text-center"><button name="add_depart_btn" class="btn btn-primary profile-button" type="submit">Add Department </button></div>
                        <?php else : ?>
                        <div id="continue" style="display:block" class="mt-5 text-center"><button name="continue_btn" class="btn btn-primary profile-button" type="submit">Continue</button></div>
                       <?php endif ?>
                        
                        
                </form>
               </div>
            </div>
        </div>

<script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../js/main.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        setInterval(function(){
            $("#time").load("../php/time.php");
        },100)

        $("#continue").click(function(){
            if ($("#depart_name").val()=="") {
                alert("Department field required!!")
            }else if($("#number").val()==""){
                 alert("No of Depart Positions field required!!")
            }else{
                $("#department").css({"display":"block"});
            $("#continue").css({"display":"none"});
            }
            
        })
        
    })
</script>
</body>
</html>