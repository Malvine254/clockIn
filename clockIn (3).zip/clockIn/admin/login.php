<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="../fonts/material-icon/css/material-design-iconic-font.min.css"> 

    <!-- Main css -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
</head>
<body>

    <div style="margin-top: 20px;">

        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                 <h2 class="text-danger text-center" id="time"></h2>
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="../images/signin-image.jpg" alt="sing up image"></figure>
                       
                    </div>

                    <div class="signin-form">
                      
                        <h2 class="form-title">Sign In</h2>
                        <?php include '../php/admin_login.php'; ?>
                        <form method="POST" class="register-form" id="login-form">
                            <div class="form-group">
                                <label for="your_id"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="email" id="your_id" placeholder="Email Address"/>
                            </div>
                            <div class="form-group">
                                <label for="your_name"><i class="zmdi zmdi-lock material-icons-name"></i></label>
                                <input type="text" name="password" id="your_name" placeholder="Password"/>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="login_btn" id="signin" class="form-submit" value="Log in"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            setInterval(function(){
                $("#time").load("php/time.php");
            },100)
            
        })
    </script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>