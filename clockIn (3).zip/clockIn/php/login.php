<?php 
if (isset($_POST['signin'])) {
	date_default_timezone_set("Africa/Nairobi");
	require_once 'config.php';
	session_start();
	$id_no = mysqli_real_escape_string($conn, $_POST['id_no']);
	$unique_code = mysqli_real_escape_string($conn, $_POST['unique_code']);
	$time_in = time();
	$sign_options = mysqli_real_escape_string($conn, $_POST['sign_options']);
	$date = date("d-m-y");
	$check = $conn->query("SELECT * FROM users WHERE unique_code='$unique_code' AND id_no='$id_no' ");
	$time_now = strtotime(date("h:i:sa"));
	if ($check->num_rows>0) {
		// $sign_in_time = "05:00:00am";
		// 	$sign_out_time = "05:00:00pm";
		    if ($sign_options !==" ") {
		    	while ($row=$check->fetch_assoc()) { 
						 if ($sign_options ==="Morning Sign In") {
						 	if ($row['time_in'] !=0) {
						 		echo "<script>alert('You have already made a sign In, please sign out!');</script>";
						 	}else{
						 		$result1 = $conn->query("UPDATE users SET time_in='$time_in',`date` = $date WHERE unique_code='$unique_code' AND id_no='$id_no'");
						 	$_SESSION['unique_code'] = $unique_code;
						 	echo "<script>alert('You have successfully Signed In');window.location.assign('index.php');</script>";
						 	}
						 	
						 }

						 else if($sign_options ==="Evening Sign Out" &&  $row['time_in']!=0 && $row['time_out']==0){
						 	if ($row['time_out'] !=0) {
						 		echo "<script>alert('You have already made a sign Out, please sign out!');window.location.assign('index.php');</script>";
						 	}else{
						 			$name = $row['name'];
						 			$time_in2 = $row['time_in'];
						 			$time_out2 =$row['time_out'];
						 			$image = $row['image'];
						 			$email = $row['email'];
						 			$department = $row['department'];
						 			$positions = $row['positions'];
						 			$id_no = $row['id_no'];
						 			$inserReport = $conn->query("INSERT INTO attendances (name,time_in,time_out,unique_code,image,email,department,positions,id_no) VALUES('$name','$time_in2','$time_in','$unique_code','$image','$email','$department','$positions','$id_no')");
						 					if ($inserReport) {
						 						if ($conn->query("UPDATE users SET time_out='$time_in'WHERE unique_code='$unique_code'")) {
						 							$_SESSION['unique_code'] = $unique_code;
						 					echo "<script>alert('You have successfully Signed Out');window.location.assign('index.php');</script>";
						 				}
						 			}else{
						 					echo "false";
						 				}
						 				
						 			//}

						 		
						 	
						 	}
						 	
						 }


						 else{
						 	$_SESSION['unique_code'] = $unique_code;
							header('location:status.php');
						 }

					}
					
					
		    		
		    	} 
		    	
		    }
		

	}

	







 ?>