<?php 
session_start();
if (isset($_SESSION['unique_code'])) {
	unset($_SESSION['unique_code']);
	header("location:../login.php");
	
}


 ?>