<?php 
if (isset($_POST['add_admin_btn'])) {
	include 'config.php';
	$name = mysqli_real_escape_string($conn,$_POST['name']);
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$name = mysqli_real_escape_string($conn,$_POST['name']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);
	$select =$conn->query("SELECT * FROM admin WHERE email = '$email'");
	if ($select->num_rows>0) {
		echo "<script>alert('Email already taken!')</script>";
	}else{
		$insert = $conn->query("INSERT INTO admin (name,email, password) VALUES('$name','$email','$password')");
		if ($insert) {
			echo "<script>alert('Admin added successfully')</script>";
		}else{
			echo "<script>alert('Server error!')</script>";
		}

	}
}
 ?>