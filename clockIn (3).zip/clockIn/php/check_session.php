<?php 
session_start();
if (isset($_SESSION['unique_code'])) {
	
}else{
	header("location:login.php");
}


 ?>