<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
</head>
<body>

    <div class="">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                    	<?php include 'php/register.php'; ?>
                        <h2 class="form-title">Sign up</h2>
                        <form enctype="multipart/form-data" method="POST" class="register-form" id="register-form">
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input required type="text" name="name" id="name" placeholder="Your Name"/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input required type="email" name="email" id="email" placeholder="Your Email"/>
                            </div>
                            <div class="form-group">
                                <label for="id_no"><i class="zmdi zmdi-account-box"></i></label>
                                <input required type="text" name="id_no" id="id_no" placeholder="Your National ID"/>
                            </div>
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-image-o"></i></label>
                                <input required type="file" name="image" id="pass" placeholder="Image"/>
                            </div>
                              <div class="form-group">
                                <label for="department"> <i class="zmdi zmdi-city-alt"> </i></label>
                                <select required style=" border-bottom-color: grey; border-top-color: transparent; border-right-color: transparent;border-left-color: transparent;margin-left: 5px;" class="form-control" name="department">
                                	<option selected disabled> Department</option>
                                	<?php 
                                    require_once 'php/config.php';
                                        $select = $conn->query("SELECT * FROM department");
                                        if ($select->num_rows>0) {
                                        while ($row=$select->fetch_assoc()) {
                                            echo "<option>".$row['department_name']."</option>";
                                        
                                        }
                                    }
                                    ?>
                                </select>
                               
                            </div>
                            <div class="form-group">
                                <label for="department"> <i class="zmdi zmdi-city-alt"> </i></label>
                                <select required style="margin-left: 5px; border-bottom-color: grey; border-top-color: transparent; border-right-color: transparent;border-left-color: transparent;" class="form-control" name="positions">
                                    <option selected disabled> Job Position</option>
                                    <?php include 'php/display_departments.php'; ?>
                                </select>
                               
                            </div>
                     
                            <div class="form-group form-button">
                                <input required type="submit" name="signup" id="signup" class="form-submit" value="Register"/>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
                        <a href="login.php" class="signup-image-link">I am already member,Login.</a>
                    </div>
                </div>
            </div>
        </section>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>