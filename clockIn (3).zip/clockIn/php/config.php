<?php 
$conn = new mySqli("localhost","root","","clock_in");
if ($conn) {
	//echo "connected";
	// code...
}


 ?>