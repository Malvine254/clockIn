<?php 
	require_once 'config.php';
	$numbering = 1;
	if (isset($_POST['search_btn_two'])) {
		$search = mysqli_real_escape_string($conn,$_POST['search']);
	 	$select = $conn->query("SELECT * FROM attendances WHERE name LIKE '%$search%' OR unique_code LIKE '%$search%'");
	 	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			echo "
			<tr>
				<td>".$numbering++."</td>
				<td>".$row['name']."</td>
				<td>".$row['email']."</td>
				<td>".checkStatusTwo($row['time_out'],$row['time_out'])."</td>
				<td>".checkStatusTwo($row['time_out'],$row['time_out'])."</td>
				<td>".$row['department']."</td>
				<td>".$row['positions']."</td>
				<td><a href='../".$row['image']."'><img width='30px' height='30px' src='../".$row['image']."' style='border-radius:50%;'/></td>
				<td><a style='padding:10px; font-size:25px;' class='zmdi zmdi-delete text-danger' href='?a=".$row['id']."'></a></td>
			<tr>";
		
		}
	}else{
		echo "<tr colspan='7'>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td class='text-danger'>No search results</td>
				<td></td>
				<td></td>
				<td></td>
				
			<tr>";
	}
	 }else{
	 	$check = $conn->query("SELECT * FROM attendances");
	if ($check->num_rows>0) {
		while ($row=$check->fetch_assoc()) {
			echo "
			<tr>
				<td>".$numbering++."</td>
				<td>".$row['name']."</td>
				<td>".$row['email']."</td>
				<td>".checkStatus($row['time_in'])."</td>
				<td>".checkStatus($row['time_out'])."</td>
				<td>".$row['department']."</td>
				<td>".$row['positions']."</td>
				<td><a href='../".$row['image']."'><img width='30px' height='30px' src='../".$row['image']."' style='border-radius:50%;'/></td>
				<td><a style='padding:10px; font-size:25px;' class='zmdi zmdi-delete text-danger' href='?a=".$row['id']."'></a></td>
			<tr>";
		
		}
	}

	 } 


function checkStatus($sign_in){
	if ($sign_in==0) {
		return "Not signed";
	}else{
		return date("d/m/y h:i:sa",$sign_in);
		 
	}

}
function checkStatusTwo($sign_in,$status){
	if ($status==0) {
		return "Not signed";
	}else{
		return date("d/m/y h:i:sa",$sign_in);
		 
	}

}

	
	


 ?>