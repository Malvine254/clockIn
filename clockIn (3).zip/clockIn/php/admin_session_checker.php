<?php 
session_start();
if (isset($_SESSION['email'])) {
	
	
}else{
	header("location:../admin/login.php");
}


 ?>