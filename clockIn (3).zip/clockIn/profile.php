<?php require 'php/check_session.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
     <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css"> 
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <script scr="bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script scr="js/popper.min.js"></script>

</head>
<style type="text/css">
    .topMenu {
  padding: 17px;
}
.topMenu a {  
  padding: 17px;
}
.topMenu a:hover {  
  padding: 17px;
  color: white;
  background: black;
}

</style>
<body style="background: teal;">
    <div class=" container rounded bg-white mt-5 mb-5 col-md-11">
           <!-- <a href="php/unset.php"><img style="padding:5px;" width="40px" height="40px" src="images/logout.jpg">Logout</a> -->
        <div class="topMenu shadow">
              <a href="index.php"><i class="zmdi zmdi-home"></i> Home</a>
              <a href="profile.php"><i class="zmdi zmdi-account"></i> Profile</a>
              <a href="attendance.php"><i class="zmdi zmdi-menu"></i> Attendance</a>
              <a href="php/unset.php"><i class="zmdi zmdi-power"></i> Logout</a>
        </div>
        <br>
        <hr>
    <div class="row">
        <div class="col-md-6 border-right">
             <?php 
                require_once 'php/config.php';
                $check = $conn->query("SELECT * FROM users WHERE unique_code='".$_SESSION['unique_code']."' ");
                if ($check->num_rows>0) {
                    while ($row=$check->fetch_assoc()) {
                       echo "<div class='d-flex flex-column align-items-center text-center p-3 py-5'><img class='rounded-circle mt-5' width='200px' height='200px' src='".$row['image']."'><span class='font-weight-bold'>".$row['name']."</span><span class='text-black-50'>".$row['email']."</span><span> </span></div>";
                    }
                }
                ?>
            
        </div>
        <div class="col-md-6 border-right">
             <?php include 'php/edit_profile.php'; ?>
            <form method='post' enctype="multipart/form-data">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Profile Information </h4>
                </div>
                <div class="row mt-3 ">
                    <?php 
                        require_once 'php/config.php';
                        $check = $conn->query("SELECT * FROM users WHERE unique_code='".$_SESSION['unique_code']."' ");
                        if ($check->num_rows>0) {
                            while ($row=$check->fetch_assoc()) {
                               echo " 
                               <div class='row'>
                                <div class='col-md-6'><label class='labels'>Full Name</label><input name='name' type='text' class='form-control' value='".$row['name']."' required></div>
                                <div class='col-md-6'><label class='labels'>Profile Picture</label><input  type='file' name='image'  class='form-control' required></div>

                               </div>
                                <div class='row'>
                                   <div class='col-md-6'><label class='labels'>Email Address</label><input disabled type='email' class='form-control' value='".$row['email']."' required></div>
                                    <div class='col-md-6'><label class='labels'>National ID</label><input disabled type='text' class='form-control'  value='".$row['id_no']."' required></div>
                                </div>
                                <div class='row'>
                                    <div class='col-md-6'><label class='labels'>Department</label><input disabled type='text' class='form-control' value='".$row['department']."' required></div>
                                    <div class='col-md-6'><label class='labels'>Position</label><input disabled type='text' class='form-control' value='Chief Executive Officer' required></div>
                                </div>
                                ";
                            }
                        }


                     ?>
                  
                </div>
                <div class="mt-5 text-center"><button name="update_profile" class="btn btn-primary profile-button" type="submit">Edit Profile</button></div>
            </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        setInterval(function(){
            $("#time").load("php/time.php");
        },100)
        
    })
</script>
</body>
</html>