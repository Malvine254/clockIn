<?php 
if (isset($_POST['update_profile'])) {
	$name = mysqli_real_escape_string($conn,$_POST['name']);
	$image = mysqli_real_escape_string($conn,$_FILES['image']['name']);
	$target = "images/".basename($image);
	$imageFileType=strtolower(pathinfo($target,PATHINFO_EXTENSION));
	$extensions_arr=array("jpg","png","jpeg");
	if (in_array($imageFileType,$extensions_arr)){
		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
			$update_name = $conn->query("UPDATE admin SET name='$name',image='$target' WHERE email='".$_SESSION['email']."'");
				if ($update_name) {
					echo "<script>alert('Updated Successfully')</script>";
				}else{
					echo "<script>alert('Failed to Update!!')</script>";
				}

		}
	}
	
}


 ?>