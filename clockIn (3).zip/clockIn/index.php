<?php require 'php/check_session.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
     <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css"> 
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <script scr="bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script scr="js/popper.min.js"></script>

</head>
<style type="text/css">
    .topMenu {
  padding: 17px;
}
.topMenu a {  
  padding: 17px;
}
.topMenu a:hover {  
  padding: 17px;
  color: white;
  background: black;
}

</style>
<body style="background: teal;">
    <div class=" container rounded bg-white mt-5 mb-5 col-md-11">
           <!-- <a href="php/unset.php"><img style="padding:5px;" width="40px" height="40px" src="images/logout.jpg">Logout</a> -->
        <div class="topMenu shadow"> 
              <a href="index.php"><i class="zmdi zmdi-home"></i> Home</a>
              <a href="profile.php"><i class="zmdi zmdi-account"></i> Profile</a>
              <a href="attendance.php"><i class="zmdi zmdi-menu"></i> Attendance</a>
              <a href="php/unset.php"><i class="zmdi zmdi-power"></i> Logout</a>
        </div>
        <br>
        <hr>
        <h4 class="text-center text-danger" id="time"> </h4>
        <hr>
        <h1 class="text-center text-primary">Welcome back <strong>
            <?php 
            include 'php/config.php';
            $unique_code = $_SESSION['unique_code'];
            $sql = $conn->query("SELECT * FROM users WHERE unique_code='$unique_code'");
            while ($row=$sql->fetch_assoc()) {
                echo $row['name'];
            }
            ?>
             
         </strong></h1>
         <h4 class="text-center">The following are your todays's attendance status</h4>
        <div class="row">
            <div class=" col-md-8 p-3 py-5">
               <div class="d-flex justify-content-between align-items-center mb-3">
                </div>
                <table class="table table-bordered">
                    <tr class="text-primary">
                        <th>#</th>
                        <th>SignIn at</th>
                        <th>SignOut at</th>
                        <th>Status</th>
                    </tr>
                   <?php include 'php/attendance_table.php'; ?>
                </table>
            </div>
            <div style="margin-top:auto;margin-bottom: auto;" class="cpl-md-12 p-3 col-md-4">
                <h4>Key:</h4>
               <div class="row">
                <div class="col">
                    <label>Late</label><p style="border-radius: 50%;width: 20px;height: 20px; background: orange;"></p>
                </div>
                <div class="col">
                <label>Present</label><p style="border-radius: 50%; width: 20px;height: 20px; background: green;"></p>
                </div>
                <div class="col">
                <label>Absent</label><p style="border-radius: 50%;width: 20px;height: 20px; background: red;"></p>
                </div>
               </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        setInterval(function(){
            $("#time").load("php/time.php");
        },100)
        
    })
</script>
</body>
</html>