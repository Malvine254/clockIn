<?php 
if (isset($_POST['signin'])) {
	date_default_timezone_set("Africa/Nairobi");
	require_once 'config.php';
	session_start();
	$id_no = mysqli_real_escape_string($conn, $_POST['id_no']);
	$unique_code = mysqli_real_escape_string($conn, $_POST['unique_code']);
	$time_in = time();
	$sign_options = mysqli_real_escape_string($conn, $_POST['sign_options']);
	$check = $conn->query("SELECT * FROM users WHERE unique_code='$unique_code' AND id_no='$id_no' ");
	$time_now = strtotime(date("h:i:sa"));
	if ($check->num_rows>0) {
		$sign_in_time = "05:00:00am";
			$sign_out_time = "05:00:00pm";
		    if ($time_now>=strtotime($sign_in_time) && $time_now<=strtotime($sign_out_time)) {
		    	while ($row=$check->fetch_assoc()) {
		    		if ($row['status']==1){
		    			$_SESSION['unique_code'] = $unique_code;
						header('location:status.php');

					}else{
						if ($row['time_in']>0) {
						$result1 = $conn->query("UPDATE users SET time_out='$time_in'WHERE unique_code='$unique_code'");
						 if ($result1) {
						 	$_SESSION['unique_code'] = $unique_code;
						 	echo "<script>alert('You have successfully Signed Out');window.location.assign('index.php');</script>";
						 }

					}else{
						$result = $conn->query("UPDATE users SET time_in='$time_in', status = 1 WHERE unique_code='$unique_code'");
						 if ($result) {
						 	$_SESSION['unique_code'] = $unique_code;
						 	echo "<script>alert('You have successfully Signed In');window.location.assign('index.php');</script>";
						 }
					}
					}
					
		    		
		    	} 	 
		    	
		    }else{
		    	
		    	$_SESSION['unique_code'] = $unique_code;
				header('location:status.php');
		    }
		

	}else{
		echo "<script>alert('Incorrect credentials!!')</script>";
	}

	

}






 ?>