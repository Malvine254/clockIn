<?php 
	require_once 'config.php';
	date_default_timezone_set("Africa/Nairobi");
	$numbering = 1;
	$check = $conn->query("SELECT * FROM users WHERE unique_code='".$_SESSION['unique_code']."' ");
	if ($check->num_rows>0) {
		while ($row=$check->fetch_assoc()) {
			echo "<tr><td>".$numbering++."</td><td>".checkSigningInStatus($row['time_in'])."</td><td>".checkSigningStatus($row['time_out'])."</td><td>".attendanceStatus($row['time_in'],$row['time_out'])." </td></tr>";
		}
	}else{
		echo "<tr><td></td><td colspan='3'></td><td></td></tr>";
	}
function checkSigningStatus($sign_out){
	if ($sign_out==0) {
		return "<p class='text-danger'>".$sign_out."</p>";
	}else{
		return date("d/m/y H:i:sa",$sign_out);
	}

}
function checkSigningInStatus($sign_in){
	if ($sign_in==0) {
		return "<p class='text-danger'>".$sign_in."</p>";
	}else{
		return date("d/m/y H:i:sa",$sign_in);
	}

}
function attendanceStatus($time_reported,$time_closed){
	$reporting_time = date(strtotime("08:00am"));
	$closing_time = date(strtotime("04:00am"));

	if ($time_reported>=$reporting_time && $time_reported==0 && $time_closed==0 && $time_reported<$reporting_time) {
		return "<p style='border-radius: 50%;width: 20px;height: 20px; background: red;'></p>";
	}else if($time_closed<=$closing_time && $time_reported!=0 && $time_closed!=0 && $time_closed>$closing_time){
		return "<p style='border-radius: 50%;width: 20px;height: 20px; background: green;'></p>";
	}else{
		return "<p style='border-radius: 50%;width: 20px;height: 20px; background: orange;'></p>";

	}

}

 ?>