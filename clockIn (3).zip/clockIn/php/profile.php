<?php 
	require_once 'config.php';
	$check = $conn->query("SELECT * FROM users WHERE unique_code='".$_SESSION['unique_code']."' ");
	if ($check->num_rows>0) {
		while ($row=$check->fetch_assoc()) {
			echo $row['image'];
		}
	}


 ?>